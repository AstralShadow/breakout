export { Brick } from "./Obstacles/Brick.js"
