const canvas = document.getElementById("brickbreakgame")
const ctx = canvas.getContext("2d")

import { Engine } from "./Engine.js"

const engine = new Engine(ctx);
